#!/usr/bin/python3
import paho.mqtt.client as mqtt
def on_connect(mqttc, obj, flags, rc):
    print("rc: " + str(rc))
def on_message(mqttc, obj, msg):
    print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
def on_subscribe(mqttc, obj, mid, granted_qos):
    print("Subscribd: " + str(mid) + " " + str(granted_qos))

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
mqttc.on_message = on_message
mqttc.on_connect = on_connect
mqttc.on_subscribe = on_subscribe

mqttc.connect("192.168.0.6", 1883, 60)
mqttc.subscribe("temperature", 0)
mqttc.loop_forever()

