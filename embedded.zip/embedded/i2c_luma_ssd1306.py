#!/usr/bin/python3
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306
from bmp280 import BMP280
from smbus2 import SMBus
import time

bus = SMBus(1)
bmp280 = BMP280(i2c_dev=bus) 

serial = i2c(port=1, address=0x3c)
device=ssd1306(serial)


try:
    while True:
        
        temp = bmp280.get_temperature()
        pressure = bmp280.get_pressure() 
        
        with canvas(device) as draw:
            draw.rectangle(device.bounding_box, outline="white", fill="black")
            draw.text((10, 10), "Temp: {:.2f} C".format(temp), fill="white")
            draw.text((10, 30), "Press: {:.2f} hPa".format(pressure), fill="white")
            
        time.sleep(2)
        
except KeyboardInterrupt:
    device.clear()
    print("Good Bye!")
