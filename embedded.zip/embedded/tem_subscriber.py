import paho.mqtt.client as mqtt
BROKER = "test.mosquitto.org"
PORT = 1883
TOPIC = "temperature"

def on_message(client, userdata, msg):
    temperature = msg.payload.decode()
    print("now temp:", temperature)

    client = mqtt.Client()
    client.on_message = on_message
    client.connect(BROKER, PORT)
    client.subscribe(TOPIC)
    print("temp sub wating")

    client.loop_forever()
