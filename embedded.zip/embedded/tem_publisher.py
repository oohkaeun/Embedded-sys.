
import board
import busio
import adafruit_bmp280

import paho.mqtt.client as mqtt

BROKER = "test.mosquitto.org"
PORT = 1883
TOPIC = "temperature"

i2c = busio.I2C(board.SCL, board.SDA)

bmp280 = adafruit_bmp280.Adafruit_BMP280_I2C(i2c, i2c_addr=0x77)

client = mqtt.Client()

client.connect(BROKER, PORT)

print("start")

while True:
    temperature = bmp280.temperature
    client.publish(TOPIC, str(round(temperture, 2)))
    print("temp :", round(temperature, 2), "C")
    time.sleep(5)

