#!/usr/bin/python3
#-*- coding: utf-8 -*-

import paho.mqtt.client as mqtt

def on_connect(mqttc, obj, flags, rc):
    print("rc: " + str(rc))

def on_message(mqttc, obj, msg):
    topic = msg.topic
    qos = str(msg.qos)
    payload = msg.payload.decode('utf-8')

    print(f"\n [Recived message]")
    print(f"Topic: {topic} | QoS: {qos} | Payload: {payload}degree")

def on_subscribe(mqttc, obj, mid, granted_qos):
    print("Subscribed: " + str(mid) + " " + str(granted_qos))

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
mqttc.on_connect = on_connect
mqttc.o_message = on_message 
mqttc.on_subscribe = on_subscribe 

broker_ip = "127.0.0.1"
mqttc.connect("127.0.0.1", 1883, 60)

mqttc.subscribe("temperature", 0) 

print("MQTT Temperature Subscriber started!")

try:
    mqttc.loop_forever() 
except KeyboardInterrupt:
    print("\nStopping Subscriber...")
finally:
    mqttc.disconnect()
    print("Disconnected safely. Exit")
