#!/usr/bin/python3
# -*- coding:utf-8 -*-

import subprocess
import paho.mqtt.client as mqtt

TOPIC = "alarm/motion"
BROKER_IP = "127.0.0.1"

def on_connect(mqttc, obj, flags, rc):
    print(f"Subscriber Connected (rc: {rc})") 
    mqttc.subscribe(TOPIC, 0)
    print(f"Subscribed to '{TOPIC}")

def on_message(mqttc, obj, msg):
    print("\n Image received from Client 1!")

    f = open('output.jpg', "wb")
    f.write(msg.payload)
    f.close()
    print("output.jpg file is saved")

    print("eog execute")
    subprocess.call(["eog", "output.jpg"])

def on_subscribe(mqttc, obj, mid, granted_qos):
    print("Subscribed Successfully: {mid} {granted_qos}")

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
mqttc.on_connect = on_connect
mqttc.on_message = on_message
mqttc.on_subscribe = on_subscribe

mqttc.connect(BROKER_IP, 1883, 60)

print("MQTT Image Subscriber Started. Waiting for alarm...")

try:
    mqttc.loop_forever()
except KeyboardInterrupt:
    print("\nStopping Subscriber...")
finally: 
    mqttc.disconnect()
    print("Safe Exit.")
          
