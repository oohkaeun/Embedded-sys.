import RPi.GPIO as GPIO
import time

buzzer = 21
sensor = 17

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(buzzer, GPIO.OUT)
GPIO.setup(sensor, GPIO.IN)

pwm=GPIO.PWM(buzzer,1000)
pwm.start(0)

time.sleep(5)

try:
    while True:
        if GPIO.input(sensor)==1:
            pwm.ChangeDutyCycle(50)
            print("Motion Detected!")
            time.sleep(3)
            
            pwm.ChangeDutyCycle(0)
            
            
        else:
            pwm.ChangeDutyCycle(0)
            time.sleep(1)
            
except KeyboardInterrupt:
    print("interrupted...")
    pwm.stop()
    GPIO.cleanup()
    

            
