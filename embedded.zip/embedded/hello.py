#! /usr/bin/python3
from flask import Flask
app = Flask(__name__)

@app.route('/')
def welcome():
	return '<h1> welcome to my world!</h1>'

if __name__ == '__main__':
	app.run(host='127.0.0.1',port=8080, threaded=True)
