#!/usr/bin/python3
import paho.mqtt.client as mqtt
def on_connect(mqttc, obj, flags, rc):
    print("rc: " + str(rc))
def on_publish(mqttc, obj, mid):
    print("mid: " + str(mid))

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
mqttc.on_connect = on_connect
mqttc.on_publish = on_publish
mqttc.connect("192.168.0.6", 1883, 60)
mqttc.loop_start()
infot = mqttc.publish("temperature", "25", qos=0)
infot.wait_for_publish()
mqttc.loop_stop()
mqttc.disconnect()

