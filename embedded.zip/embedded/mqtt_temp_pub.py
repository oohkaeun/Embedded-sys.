#!/usr/bin/python3
#-*- coding: utf-8 -*-

import time
import paho.mqtt.client as mqtt
from bmp280 import BMP280
from smbus2 import SMBus
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)

bus = SMBus(1)
bmp280 = BMP280(i2c_dev=bus, i2c_addr=0x76)

def on_connect(client, userdata, flags, rc): 
    print("MQTT broker connected! (rc: " + str(rc) + ")") 
    client.subscribe("home/led", 0)

def on_message(client, userdata, msg):
    command = msg.payload.decode()
    if command == "on":
        print("LED ON")
        GPIO.output(4, True)
    elif command == "off":
        print("LED OFF")
        GPIO.output(4, False)
    else:
        print("Unkniwn Command")

client = mqtt.Client()
client.on_connect = on_connect 
client.on_message = on_message

broker_ip = "203.250.133.87"
broker_port = 1883 
client.connect(broker_ip, broker_port, 60) 

client.loop_start()

print("temp notification sevice loading... if Ctrl+C end")

try:
    while True:
        try:
            temperature = bmp280.get_temperature()
            payload = "{:.2f}".format(temperature) 

            client.publish("home/temperature", payload, qos=0) 
            print(f"[Publish] Topic: home/temperature -> message: {payload}C")

        except Exception as sensor_error:
            print("Sensor Reading failed:", sensor_error)

        time.sleep(3)

except KeyboardInterrupt: 
    print("Program end")
    client.loop_stop()
    client.disconnect()
    GPIO.cleanup()
