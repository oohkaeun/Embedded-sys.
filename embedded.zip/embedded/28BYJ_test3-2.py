#!/usr/bin/python3
import RPi.GPIO as GPIO
import time

in1 = 17
in2 = 18
in3 = 27
in4 = 22

step_sleep = 0.002
step_count = 2048
direction = True

step_sequence = [[1,0,0,1],
                 [1,0,0,0],
                 [1,1,0,0],
                 [0,1,0,0],
                 [0,1,1,0],
                 [0,0,1,0],
                 [0,0,1,1],
                 [0,0,0,1]]

GPIO.setmode(GPIO.BCM)
GPIO.setup(in1, GPIO.OUT)
GPIO.setup(in2, GPIO.OUT)
GPIO.setup(in3, GPIO.OUT)
GPIO.setup(in4, GPIO.OUT)

GPIO.output(in1, GPIO.LOW)
GPIO.output(in2, GPIO.LOW)
GPIO.output(in3, GPIO.LOW)
GPIO.output(in4, GPIO.LOW)

pins = [in1, in2, in3, in4]
step_counter = 0
current_step = 0
first_run = True

def cleanup():
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.LOW)
    GPIO.output(in3, GPIO.LOW)
    GPIO.output(in4, GPIO.LOW)
    GPIO.cleanup()

def move(step, direction):
    global step_counter, current_step
    
    for i in range(abs(step)):
        for pin in range(0, len(pins)):
            GPIO.output(pins[pin], step_sequence[step_counter][pin])
        
        if direction == "cw":
            step_counter = (step_counter - 1) % 8
            current_step += 1
            
        else:
            step_counter = (step_counter + 1) % 8
            current_step -= 1
            
        time.sleep(step_sleep)


try:
    while True:
        angle = float(input("Input the angle to move (0~360): "))
        target_steps = int(angle * 4074 / 360)
        
        if not first_run:
            print("to zero")
            if current_step > 0:
                move(current_step, "ccw")
            elif current_step < 0:
                move(abs(current_step), "cw")
            current_step = 0
            time.sleep(0.5)
    
        print(f"{angle} move")
        move(target_steps, "cw")
        
        first_run = False


except KeyboardInterrupt:
    cleanup()
    exit(1)
            

cleanup()
exit(0)


