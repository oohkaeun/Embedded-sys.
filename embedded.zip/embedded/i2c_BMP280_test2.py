#!/usr/bin/python3
import RPi.GPIO as GPIO 
import time
from bmp280 import BMP280
from smbus2 import SMBus

print("press ctrl-c to stop!")
 
bus = SMBus(1)
bmp280 = BMP280(i2c_dev=bus)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(21, GPIO.OUT)
p = GPIO.PWM(21, 500)
p.start(0) 

while True:
    try:
        temperature = bmp280.get_temperature()
        pressure = bmp280.get_pressure()
        print('Temperature = {:.2f}C'.format(temperature))
        print('Pressure = {:.1f}hPa'.format(pressure))
        print("=========================")
        if temperature >= 26:
            p.ChangeDutyCycle(50)
            time.sleep(1)
            p.ChangeDutyCycle(0)
        time.sleep(2)
        
    except KeyboardInterrupt:
        exit(0)
        
p.stop()
GPIO.cleanup()