import RPi.GPIO as GPIO
import time

ledpin = 18

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(ledpin, GPIO.OUT)
#GPIO.output(ledpin, GPIO.LOW)

for i in range(1, 20):
    GPIO.output(ledpin, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(ledpin, GPIO.LOW)
    time.sleep(1)