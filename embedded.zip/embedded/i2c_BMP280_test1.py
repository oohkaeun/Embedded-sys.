#!/usr/bin/python3
import RPi.GPIO as GPIO 
import time
from bmp280 import BMP280
from smbus2 import SMBus

print("press ctrl-c to stop!")

led = 21 
bus = SMBus(1)
bmp280 = BMP280(i2c_dev=bus)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(led, GPIO.OUT) 

while True:
    try:
        temperature = bmp280.get_temperature()
        pressure = bmp280.get_pressure()
        print('Temperature = {:.2f}C'.format(temperature))
        print('Pressure = {:.1f}hPa'.format(pressure))
        print("=========================")
        if temperature >= 26:
            GPIO.output(led, 1)
            time.sleep(1)
            GPIO.output(led, 0)
        time.sleep(2)
        
    except KeyboardInterrupt:
        exit(0)
    
GPIO.cleanup() 
    