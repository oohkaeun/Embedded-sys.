#!/usr/bin/python3
import RPi.GPIO as GPIO
import time

in1 = 17
in2 = 18
in3 = 27
in4 = 22

button = 23

step_sleep = 0.002
step_count = 2048
#direction = True

step_sequence = [[1,0,0,1],
                 [1,0,0,0],
                 [1,1,0,0],
                 [0,1,0,0],
                 [0,1,1,0],
                 [0,0,1,0],
                 [0,0,1,1],
                 [0,0,0,1]]

GPIO.setmode(GPIO.BCM)

GPIO.setup(in1, GPIO.OUT)
GPIO.setup(in2, GPIO.OUT)
GPIO.setup(in3, GPIO.OUT)
GPIO.setup(in4, GPIO.OUT)

GPIO.output(in1, GPIO.LOW)
GPIO.output(in2, GPIO.LOW)
GPIO.output(in3, GPIO.LOW)
GPIO.output(in4, GPIO.LOW)

GPIO.setup(button, GPIO.IN, pull_up_down = GPIO.PUD_UP)

pins = [in1, in2, in3, in4]
step_counter = 0

def motor_off():
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.LOW)
    GPIO.output(in3, GPIO.LOW)
    GPIO.output(in4, GPIO.LOW)
    
def cleanup():
    motor_off()
    GPIO.cleanup()

try:
    while True:
        if GPIO.input(button) == GPIO.LOW:
            for i in range(step_count):
                for pin in range(0, len(pins)):
                    GPIO.output(pins[pin], step_sequence[step_counter][pin])
                step_counter = (step_counter - 1) % 8
                time.sleep(step_sleep)
            
        else:
            motor_off()
    
except KeyboardInterrupt:
    cleanup()
    exit(1)


cleanup()
exit(0)

