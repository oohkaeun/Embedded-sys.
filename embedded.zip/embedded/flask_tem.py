#! /usr/bin/python3

from flask import Flask, render_template, request
from bmp280 import BMP280
from smbus2 import SMBus

bus = SMBus(1)
bmp280 = BMP280(i2c_dev=bus)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sensor', methods=['GET'])
def sensor():
    action = request.args.get('action')
    
    if action == 'read':
        try:
            temperature = bmp280.get_temperature()
            pressure = bmp280.get_pressure()

            return render_template(
                    'result.html',
                    temp=round(temperature, 2),
                    press=round(pressure, 2)
            )
            
        except Exception as e:
            return f"<h1>error: {e}</h1>"

    else:
        return "<h1>Bad command!</h1>" 
    
if __name__=='__main__':
    app.run(
            host='0.0.0.0',
            port=8080,
            threaded=True,
            debug=True
            )

