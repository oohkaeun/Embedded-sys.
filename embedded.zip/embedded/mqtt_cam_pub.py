#!/usr/bin/python3
#-*- coding: utf-8 -*-

import time
import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt
from picamera2 import Picamera2

PIR_PIN = 18
TOPIC = "alarm/motion"
BROKER_IP = "127.0.0.1"

GPIO.setmode(GPIO.BCM)
GPIO.setup(PIR_PIN, GPIO.IN)

print("Initializing Camera...")
camera = Picamera2()
camera_config = camera.create_still_configuration(
        main={"size": (1920, 1028)},
        lores={"size": (640, 480)}
)
camera.configure(camera_config)
camera.start()
time.sleep(2)

def on_connect(mqttc, obj, flags, rc):
    print(f"Publisher Connected (rc: {rc}")

mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1)
mqttc.on_connect = on_connect
mqttc.connect("127.0.0.1", 1883, 60)
mqttc.loop_start()

print("Wating For motion...")

try:
    while True:
        if GPIO.input(PIR_PIN) == GPIO.HIGH:
            print("\n otion Detected!")
            camera.capture_file('motion.jpg')
            print("Still image taken successfully")
            
            print("Sending image via MQTT")
            with open("motion.jpg", "rb") as f:
                fileContent = f.read()
                byteArr = bytearray(fileContent)
                mqttc.publish(TOPIC, byteArr, qos=0)

            print("Image published successfully!")

            time.sleep(5)
            print("Waiting For motion...")

        time.sleep(0.1)
        
except KeyboardInterrupt:
    print("\nStopping Publisher...")

finally:
    camera.stop()
    mqttc.loop_stop()
    mqttc.disconnect()
    GPIO.cleanup()
    print("Disconnected safely. Exit")
