import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

PIN = 4
GPIO.setup(PIN, GPIO.OUT)

pwm = GPIO.PWM(PIN, 1000)   # 1 kHz PWM frequency
pwm.start(0)                # start with 0% duty cycle

try:
    while True:
        for duty in range(0, 101, 5):   # increase brightness/speed
            pwm.ChangeDutyCycle(duty)
            time.sleep(0.1)

        for duty in range(100, -1, -5): # decrease brightness/speed
            pwm.ChangeDutyCycle(duty)
            time.sleep(0.1)

except KeyboardInterrupt:
    pass

pwm.stop()
GPIO.cleanup()