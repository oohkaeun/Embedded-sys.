import spidev
import time
import RPi.GPIO as GPIO

ledpin = 18

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(ledpin, GPIO.OUT)

spi = spidev.SpiDev()
spi.open(0,0)
spi.max_speed_hz = 1350000

def read_adc(channel):
    if channel < 0 or channel > 7:
        return -1
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    data = ((adc[1] & 3) << 8) + adc[2]
    return data

try:
    while True:
        light_level = read_adc(0)
        voltage = (light_level * 3.3) / 1023
        print(f"LDR: {light_level}, Vol: {voltage:.2f}V")
        time.sleep(1)
        
        if light_level < 600:
            GPIO.output(ledpin, GPIO.HIGH)
        else:
            GPIO.output(ledpin, GPIO.LOW)

except KeyboardInterrupt:
    print("close")
    
finally:
    spi.close()
    GPIO.cleanup()

