#!/usr/bin/python3\

#import RPi.GPIO as GPIO
from gpiozero import MotionSensor, PWMOutputDevice
from picamera2 import Picamera2, Preview
from time import sleep

pir = MotionSensor(17)
buzzer = PWMOutputDevice(18)

camera = Picamera2()
camera_config = camera.create_preview_configuration()
camera.configure(camera_config)

camera.start_preview(Preview.QTGL)
camera.start()

print("Motion Detection System Ready...")
sleep(5)
#quit_flag = False
i = 0

def motion_detected():
    global i
    i += 1
    
    print("Motion dtected!")
    
    camera.capture_file('image_{}.jpg'.format(i))
    print('still image has been taken')
    
    buzzer.value = 0.5
    sleep(5)
    buzzer.value = 0
    
pir.when_motion = motion_detected

while True:
    sleep(1)

