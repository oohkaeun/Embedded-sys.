import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)

p = GPIO.PWM(4, 50)
p.start(0)

try:
    while 1:
            p.ChangeFrequency(50)
            time.sleep(0.1)
            p.ChangeFrequency(100)
            time.sleep(0.1)																	
except KeyboardInterrupt:
    pass
                                                                                    
p.stop()																				
GPIO.cleanup()       							