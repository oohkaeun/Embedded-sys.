import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(4, GPIO.OUT)

p = GPIO.PWM(4, 1000)
p.start(50)

try:
    while 1:
        for freq in range(300, 701, 20):   # increase brightness/speed
            p.ChangeFrequency(freq)
            time.sleep(0.01)

        for freq in range(700, 299, -20): # decrease brightness/speed
            p.ChangeFrequency(freq)
            time.sleep(0.01)
            
except KeyboardInterrupt:
    pass
                                                                                    
p.stop()																				
GPIO.cleanup()       							
